﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ast_explosion : MonoBehaviour {

    void Start()
    {
        StartCoroutine(SelfDestruct());
    }
    IEnumerator SelfDestruct()
    {
        yield return new WaitForSeconds(0.6f);
        Destroy(gameObject);
    }

    // Update is called once per frame
    void Update () {
		
	}
}
