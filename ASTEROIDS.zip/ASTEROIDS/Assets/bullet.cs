﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour {
    private float max_x = 12;
    private float max_y = 12;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (transform.position.x > max_x || transform.position.x < -max_x) Destroy(gameObject);
        if (transform.position.y > max_y || transform.position.y < -max_y) Destroy(gameObject);

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.tag == "Asteroid")
        {
            Destroy(gameObject);
            asteroid ast = collision.GetComponent<asteroid>();
           ast.takeDamage();
        }
    }
}
