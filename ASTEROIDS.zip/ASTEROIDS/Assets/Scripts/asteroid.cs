﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class asteroid : MonoBehaviour {
    private Rigidbody2D rb;
    public GameObject asteroidPrefab;
    private GameController gameController;
    public GameObject astExplosion_prefab;
    public int scale;
    public int max_scale = 2;
    public float newOffset = 1;
    private float health = 2;
    [SerializeField] float max_x = 10F;
    [SerializeField] float max_y = 5F;
    [SerializeField] float max_speed = 2F;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        transform.position = new Vector3(Random.Range(-max_x, max_x), Random.Range(-max_y, max_y));
        rb.velocity = Quaternion.Euler(0, 0, Random.Range(0, 360)) * new Vector3(Random.Range(0.5F, max_speed), 0, 0);
        scale = max_scale;
    }
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //if asteroid goes off, wrap around
        if (transform.position.x < -max_x)
        {
            transform.position = new Vector2(max_x, transform.position.y);
        }
        else if (transform.position.x > max_x)
        {
            transform.position = new Vector2(-max_x, transform.position.y);
        }
        if (transform.position.y < -max_y)
        {
            transform.position = new Vector2(transform.position.x, max_y);
        }
        else if (transform.position.y > max_y)
        {
            transform.position = new Vector2(transform.position.x, -max_y);
        }




        //limit maxspeed
        if(rb.velocity.magnitude > max_speed)
        {
            rb.velocity = rb.velocity.normalized * max_speed;
        }
    }

    public void takeDamage()
    {
        health--;
        
        if(health == 0)
        {
            die();
        }
    }

    private void die()
    {
        Destroy(gameObject);
        gameController.num_asteroids -= 1;

        GameObject explosion = Instantiate(astExplosion_prefab);
        explosion.transform.position = transform.position;
        if (scale > 0) spawnChildren();
    }

        private void spawnChildren()
        {
        Vector2[] angle = new Vector2[4];
        angle[0] = new Vector2(1, 0);
        angle[1] = new Vector2(0, 1);
        angle[2] = new Vector2(-1, 0);
        angle[3] = new Vector2(0, -1);
        
        for (int i = 0; i < 4; i++)
            {

                GameObject newAsteroid;

                newAsteroid = Instantiate(asteroidPrefab);
            newAsteroid.GetComponent<asteroid>().setGameController(gameController);
            newAsteroid.gameObject.tag = "Asteroid";
            PolygonCollider2D pc = newAsteroid.GetComponent<PolygonCollider2D>();
            pc.enabled = true;
            float randomAngle = Random.Range(0, 360);
            newAsteroid.transform.position = transform.position + (Vector3) angle[i] * 1;
            newAsteroid.transform.localScale = transform.localScale / 2;

            asteroid asteroidHandle = newAsteroid.GetComponent<asteroid>();
            asteroidHandle.newOffset = newOffset / 2;
            asteroidHandle.scale = scale - 1;
            Rigidbody2D rb = newAsteroid.GetComponent<Rigidbody2D>();
            rb.AddForce(angle[i] * newOffset * 2);


            }
        gameController.num_asteroids += 4;
        }

    public void setGameController(GameController _gameController)
    {
        gameController = _gameController;
    }
}

