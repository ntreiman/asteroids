﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spaceship : MonoBehaviour {
    public GameObject bulletPrefab;
    public GameObject explosionPrefab;
    public GameController gameController;
    private Vector3 shipDirection = new Vector3(0, 1, 0);
    private Rigidbody2D rb;
    private float turnSpeed = 180;
    [SerializeField] float thrust = 0.0005F;
    [SerializeField] float max_x = 11F;
    [SerializeField] float max_y = 5F;
    [SerializeField] float bulletSpeed = 20F;
    private AudioSource aud;
    public AudioClip shootingSound;
    public AudioClip thrustersSound;
    // Use this for initialization
    void Start() {

    }
    private void Awake()
    {
        aud = GetComponent<AudioSource>();

        rb = GetComponent<Rigidbody2D>();
        //transform.position = new Vector3(Random.Range(-max_x, max_x), Random.Range(-max_y, max_y));
        transform.position = new Vector3(-10.21f, -4f);
    }
    // Update is called once per frame
    void Update() {
        if (Input.GetKey("j"))
        {
            float turnAngle = turnSpeed * Time.deltaTime;
            //turn left
            transform.Rotate(0, 0, turnAngle);
            shipDirection = Quaternion.Euler(0, 0, turnAngle) * shipDirection;

        }
        if (Input.GetKey("l"))
        {
            float turnAngle = -turnSpeed * Time.deltaTime;
            //turn left
            transform.Rotate(0, 0, turnAngle);
            shipDirection = Quaternion.Euler(0, 0, turnAngle) * shipDirection;

        }
        if (Input.GetKey("k"))
        {
            rb.AddForce(shipDirection * thrust);
            aud.clip = thrustersSound;
            aud.Play();
        }

        if (Input.GetKeyDown("k"))
        {
            aud.clip = thrustersSound;
            aud.Play();
        }

        if (Input.GetKeyUp("k"))
        {
            aud.clip = thrustersSound;
            aud.Stop();
        }

        if (Input.GetKeyDown("space"))
        {
            GameObject bullet = Instantiate(bulletPrefab);
            bullet.transform.position = transform.position;
            bullet.GetComponent<Rigidbody2D>().velocity = shipDirection * bulletSpeed;
            bullet.transform.eulerAngles = transform.eulerAngles + new Vector3(0, 0, 90);
            aud.PlayOneShot(shootingSound);
        }

        //if ship goes off, wrap around
        if (transform.position.x < -max_x)
        {
            transform.position = new Vector2(max_x, transform.position.y);
        }
        else if (transform.position.x > max_x)
        {
            transform.position = new Vector2(-max_x, transform.position.y);
        }
        if (transform.position.y < -max_y)
        {
            transform.position = new Vector2(transform.position.x, max_y);
        }
        else if (transform.position.y > max_y)
        {
            transform.position = new Vector2(transform.position.x, -max_y);
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Asteroid")
        {
            GameObject explosion = Instantiate(explosionPrefab);
            explosion.transform.position = transform.position;
            Destroy(gameObject);
        }
    }

    public void setGameController(GameController _gameController)
    {
        gameController = _gameController;
    }
}
