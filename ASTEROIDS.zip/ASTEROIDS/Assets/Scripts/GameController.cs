﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {
    public GameObject asteroidPrefab;
    public GameObject spaceShipPrefab;

    public int num_asteroids = 4;
    [SerializeField] float minCollision = 3;
    private void Awake()
    {
        initializeLevel();
    }
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void initializeLevel()
    {
        for(int i = 0; i < num_asteroids; i++)
        {
            spawnAsteroid();
        }
        spawnSpaceship();
    }
    private void spawnSpaceship()
    {
        bool valid;
        GameObject sp;
        do
        {
            sp = Instantiate(spaceShipPrefab);
            sp.gameObject.tag = "Spaceship";
            valid = checktooclose(sp);
        } while (valid == false);
    }


    private void spawnAsteroid()
    {
        bool valid;
        GameObject newAsteroid;
        do
        {
            newAsteroid = Instantiate(asteroidPrefab);
            newAsteroid.gameObject.tag = "Asteroid";
            newAsteroid.GetComponent<asteroid>().setGameController(this);

            valid = checktooclose(newAsteroid);
        } while (valid == false);
    }
    public bool checktooclose(GameObject test)
    {
        GameObject[] asteroids = GameObject.FindGameObjectsWithTag("Asteroid");
        foreach(GameObject asteroid in asteroids)
        {
            if(asteroid != test)
            {
                if (Vector3.Distance(test.transform.position, asteroid.transform.position) < minCollision)
                {
                    Destroy(test);
                    return false;

                }
                else
                {
                    return true;
                }
            }
        }
        return false;

    }

}
