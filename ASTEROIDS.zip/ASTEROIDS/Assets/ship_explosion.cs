﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ship_explosion : MonoBehaviour {

	// Use this for initialization
	void Start () {
        StartCoroutine(SelfDestruct());
	}
	IEnumerator SelfDestruct()
    {
        yield return new WaitForSeconds(0.6f);
        Destroy(gameObject);
    }
	// Update is called once per frame
	void Update () {
		
	}
}
